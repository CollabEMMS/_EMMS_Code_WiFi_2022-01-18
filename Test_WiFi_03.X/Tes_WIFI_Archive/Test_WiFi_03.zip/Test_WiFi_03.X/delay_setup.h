#ifndef DELAY_SETUP_H
#define	DELAY_SETUP_H

#include "pic_frequency.h"
#include <libpic30.h>


#endif	/* XC_HEADER_TEMPLATE_H */

