// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef WiFi_H
#define	WiFi_H
//#endif is at end of file

#include <p24FV32KA302.h>
extern void wifi( bool init);


// Comment a function and leverage automatic documentation with slash star star
/**
    <p><b>Function prototype:</b></p>
    <p><b>Summary:</b></p>
    <p><b>Description:</b></p>
    <p><b>Precondition:</b></p>
    <p><b>Parameters:</b></p>
    <p><b>Returns:</b></p>
    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation


#endif	/* XC_HEADER_TEMPLATE_H */



