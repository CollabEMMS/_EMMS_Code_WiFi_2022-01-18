#ifndef TEST_LEDS_H
#define	TEST_LEDS_H

#define LED1DIR TRISBbits.TRISB15
#define LED2DIR TRISBbits.TRISB14

#define LED1SET LATBbits.LATB15
#define LED2SET LATBbits.LATB14

#define LED1READ PORTBbits.RB15
#define LED2READ PORTBbits.RB14


#endif	/* XC_HEADER_TEMPLATE_H */

