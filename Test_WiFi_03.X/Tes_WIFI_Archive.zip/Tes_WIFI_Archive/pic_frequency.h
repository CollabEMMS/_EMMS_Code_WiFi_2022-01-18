#ifndef pic_frequency_H
#define	pic_frequency_H
// #endif at end of file

#define FOSC (32000000) // 8mhz with 4x PLL
#define FCY (FOSC/4)  // instruction speed (4 clocks per instruction))

#endif	/* pic_frequency_H */

